using System.Windows.Forms;

namespace Just_Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "1234")
            {
                MessageBox.Show("Password is correct!");
            }

            if (textBox1.Text != "1234")
            {
                MessageBox.Show("Password is incorrect!");
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
